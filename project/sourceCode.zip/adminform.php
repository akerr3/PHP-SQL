<!DOCTYPE html>
<html>
<head>
	<title>php</title>
</head>
<body>
<a href ="form2.php">Add Medicine</a>
<a href = "adminlist.php">View List of Medicines</a>
<a href = "delete.php">Delete Medicines</a>
<a href = "updateMed.php">Update Medicines</a>
<a href = "deleteCustomer.php">Remover Customer</a>
<a href = "index.php">Logout</a>

</form>
</body>
</html>