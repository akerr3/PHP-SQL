<?php

mysql_connect("localhost","root","","medicine");
mysql_select_db("medicine");

?>